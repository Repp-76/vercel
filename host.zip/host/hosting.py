"""
hosting.py
REP76 WEB HOSTING BOT

Orchestrates the deployment workflow: turning a downloaded HTML file
or ZIP archive into a file-map Vercel can deploy, then driving the
vercel.py client through upload -> create -> poll -> result.
"""

import os
import shutil

import config
import security
import vercel
from utils import logger, new_deployment_id, make_project_slug


class HostingError(Exception):
    """User-facing deployment failure (safe to show the raw message)."""


def make_temp_dir() -> str:
    deployment_id = new_deployment_id()
    path = os.path.join(config.TEMP_DIR, deployment_id)
    os.makedirs(path, exist_ok=True)
    return path


def cleanup_temp_dir(path: str) -> None:
    try:
        if os.path.isdir(path):
            shutil.rmtree(path, ignore_errors=True)
    except OSError:
        pass


def build_files_from_html(html_bytes: bytes, original_filename: str) -> dict:
    """
    A single uploaded HTML file always becomes the deployment's
    index.html entry point. Content is passed through unmodified.
    """
    if len(html_bytes) > config.MAX_FILE_SIZE:
        raise HostingError("The uploaded file exceeds the allowed size limit.")

    return {"index.html": html_bytes}


def build_files_from_zip(zip_path: str, temp_dir: str) -> dict:
    """
    Validates and safely extracts a ZIP archive, then walks the
    extracted directory into a {relative_path: bytes} map ready for
    Vercel. Content is passed through unmodified.
    """
    if os.path.getsize(zip_path) > config.MAX_ZIP_SIZE:
        raise HostingError("The uploaded file exceeds the allowed size limit.")

    try:
        zf = security.validate_zip(zip_path)
        extract_dir = os.path.join(temp_dir, "extracted")
        security.safe_extract(zf, extract_dir)
    except security.SecurityError as exc:
        raise HostingError(str(exc))

    files = {}
    for root, _dirs, filenames in os.walk(extract_dir):
        for name in filenames:
            full_path = os.path.join(root, name)
            relative_path = os.path.relpath(full_path, extract_dir).replace(os.sep, "/")
            with open(full_path, "rb") as f:
                files[relative_path] = f.read()

    return files


def deploy(files: dict, source_filename: str) -> str:
    """
    Runs the full Vercel deployment pipeline for a prepared file map.
    Returns the live deployment URL on success. Raises HostingError
    on any failure, with a message safe to show the user.
    """
    project_name = make_project_slug(source_filename)

    try:
        deployment_id = vercel.create_deployment(files, project_name)
        status = vercel.wait_for_deployment(deployment_id, config.DEPLOYMENT_TIMEOUT)
    except vercel.VercelError as exc:
        logger.info("Deployment failed | reason=%s", exc)
        raise HostingError(str(exc))

    if status["state"] != "READY" or not status["url"]:
        logger.info("Deployment ended in state=%s", status["state"])
        raise HostingError(f"Deployment ended with status: {status['state']}.")

    logger.info("Deployment ready | url=%s", status["url"])
    return status["url"]
