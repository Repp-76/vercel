"""
vercel.py
REP76 WEB HOSTING BOT

Real integration with the Vercel REST API (api.vercel.com).
Flow:
    1. Upload every file's raw bytes to /v2/files (content-addressed
       by its sha1 digest).
    2. Create a deployment at /v13/deployments referencing those
       files by sha1 + size.
    3. Poll /v13/deployments/{id} until the build reaches a READY or
       failure state.

No browser automation, no fake URLs: every URL returned here comes
directly from Vercel's API response.
"""

import hashlib
import time

import requests

import config
from utils import logger

API_BASE = "https://api.vercel.com"


class VercelError(Exception):
    """Raised when the Vercel API rejects a request or a deployment fails."""


def _headers() -> dict:
    return {"Authorization": f"Bearer {config.VERCEL_API_KEY}"}


def _team_query() -> dict:
    if config.VERCEL_TEAM_ID:
        return {"teamId": config.VERCEL_TEAM_ID}
    return {}


def _sha1(data: bytes) -> str:
    return hashlib.sha1(data).hexdigest()


def upload_file(data: bytes) -> str:
    """
    Uploads raw file bytes to Vercel's content-addressable file store.
    Returns the sha1 digest used to reference the file in a deployment.
    """
    digest = _sha1(data)

    response = requests.post(
        f"{API_BASE}/v2/files",
        params=_team_query(),
        headers={
            **_headers(),
            "Content-Length": str(len(data)),
            "x-vercel-digest": digest,
        },
        data=data,
        timeout=30,
    )

    if response.status_code not in (200, 201):
        raise VercelError(
            f"Failed to upload file to Vercel (status {response.status_code})."
        )

    return digest


def create_deployment(files: dict, project_name: str) -> str:
    """
    files: dict mapping relative path (e.g. "index.html") -> raw bytes.
    Uploads every file, then creates the deployment.
    Returns the deployment id.
    """
    deployment_files = []

    for relative_path, data in files.items():
        digest = upload_file(data)
        deployment_files.append(
            {
                "file": relative_path,
                "sha": digest,
                "size": len(data),
            }
        )

    payload = {
        "name": project_name,
        "files": deployment_files,
        "target": "production",
        "projectSettings": {
            "framework": None,
        },
    }

    if config.VERCEL_PROJECT_ID:
        payload["project"] = config.VERCEL_PROJECT_ID

    response = requests.post(
        f"{API_BASE}/v13/deployments",
        params=_team_query(),
        headers={**_headers(), "Content-Type": "application/json"},
        json=payload,
        timeout=30,
    )

    if response.status_code not in (200, 201):
        detail = ""
        try:
            detail = response.json().get("error", {}).get("message", "")
        except ValueError:
            pass
        raise VercelError(f"Vercel rejected the deployment. {detail}".strip())

    body = response.json()
    deployment_id = body.get("id")
    if not deployment_id:
        raise VercelError("Vercel did not return a deployment id.")

    logger.info("Deployment created | id=%s", deployment_id)
    return deployment_id


def get_deployment_status(deployment_id: str) -> dict:
    """
    Returns {"state": str, "url": str|None} for the given deployment.
    state is one of: QUEUED, BUILDING, READY, ERROR, CANCELED, INITIALIZING.
    """
    response = requests.get(
        f"{API_BASE}/v13/deployments/{deployment_id}",
        params=_team_query(),
        headers=_headers(),
        timeout=30,
    )

    if response.status_code != 200:
        raise VercelError(
            f"Failed to fetch deployment status (status {response.status_code})."
        )

    body = response.json()
    state = body.get("readyState", "UNKNOWN")
    url = body.get("url")
    return {"state": state, "url": f"https://{url}" if url else None}


def wait_for_deployment(deployment_id: str, timeout_seconds: int) -> dict:
    """
    Polls the deployment until it reaches a terminal state or the
    timeout elapses. Returns the final status dict.
    """
    started = time.time()
    poll_interval = 3

    while True:
        status = get_deployment_status(deployment_id)
        state = status["state"]

        if state in ("READY", "ERROR", "CANCELED"):
            return status

        if time.time() - started > timeout_seconds:
            raise VercelError("Deployment timed out while waiting for Vercel.")

        time.sleep(poll_interval)
