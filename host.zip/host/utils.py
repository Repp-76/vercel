"""
utils.py
REP76 WEB HOSTING BOT

Shared helpers: logging setup, rate limiting, unique id generation,
and safe-name utilities used across the project.
"""

import logging
import time
import uuid
import re
import threading

import config


# ------------------------------------------------------------------
# LOGGING
# ------------------------------------------------------------------

def setup_logging() -> logging.Logger:
    """
    Configures a single shared logger for the whole bot.
    Never logs credentials, file contents, or other sensitive data.
    """
    logger = logging.getLogger("rep76")
    logger.setLevel(logging.INFO)

    if logger.handlers:
        # Avoid duplicate handlers if setup_logging() is called twice.
        return logger

    formatter = logging.Formatter(
        fmt="%(asctime)s | %(levelname)s | %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    )

    file_handler = logging.FileHandler(config.LOG_FILE, encoding="utf-8")
    file_handler.setFormatter(formatter)

    console_handler = logging.StreamHandler()
    console_handler.setFormatter(formatter)

    logger.addHandler(file_handler)
    logger.addHandler(console_handler)

    # python-telegram-bot and httpx are noisy on INFO; keep them quieter.
    logging.getLogger("httpx").setLevel(logging.WARNING)
    logging.getLogger("telegram").setLevel(logging.WARNING)

    return logger


logger = setup_logging()


# ------------------------------------------------------------------
# UNIQUE IDS
# ------------------------------------------------------------------

def new_deployment_id() -> str:
    """Returns a short unique id used for temp directories and logs."""
    return uuid.uuid4().hex[:12]


# ------------------------------------------------------------------
# RATE LIMITING (per-user hosting cooldown)
# ------------------------------------------------------------------

class RateLimiter:
    """
    Thread-safe in-memory cooldown tracker.
    Only guards against spamming /hosting; it is intentionally not
    persisted, since a bot restart resetting cooldowns is harmless.
    """

    def __init__(self, cooldown_seconds: int):
        self._cooldown = cooldown_seconds
        self._last_attempt = {}
        self._lock = threading.Lock()

    def is_limited(self, user_id: int) -> bool:
        with self._lock:
            last = self._last_attempt.get(user_id)
            if last is None:
                return False
            return (time.time() - last) < self._cooldown

    def remaining_seconds(self, user_id: int) -> int:
        with self._lock:
            last = self._last_attempt.get(user_id)
            if last is None:
                return 0
            remaining = self._cooldown - (time.time() - last)
            return max(0, int(remaining))

    def record_attempt(self, user_id: int) -> None:
        with self._lock:
            self._last_attempt[user_id] = time.time()


rate_limiter = RateLimiter(config.HOSTING_COOLDOWN)


# ------------------------------------------------------------------
# NAME / SLUG HELPERS
# ------------------------------------------------------------------

_SLUG_RE = re.compile(r"[^a-z0-9-]+")


def make_project_slug(seed: str) -> str:
    """
    Builds a Vercel-safe project name: lowercase, alphanumeric and
    hyphens only, prefixed with rep76 and suffixed with a short
    unique token so concurrent deployments never collide.
    """
    base = seed.rsplit(".", 1)[0].lower()
    base = base.replace("_", "-").replace(" ", "-")
    base = _SLUG_RE.sub("-", base).strip("-")
    if not base:
        base = "site"
    base = base[:40]
    return f"rep76-{base}-{uuid.uuid4().hex[:6]}"


def format_bytes(size: int) -> str:
    for unit in ("B", "KB", "MB", "GB"):
        if size < 1024:
            return f"{size:.1f} {unit}" if unit != "B" else f"{size} {unit}"
        size /= 1024
    return f"{size:.1f} TB"
