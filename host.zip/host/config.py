# ============================================================
# REP76 WEB HOSTING BOT
# CONFIGURATION
# ============================================================
#
# This file holds every credential and setting the bot needs.
# DO NOT share this file publicly and DO NOT push it to a public
# git repository. It is already listed in .gitignore.
# ============================================================


# ============================================================
# TELEGRAM BOT TOKEN
# Masukkan Bot Token daripada BotFather di sini.
# (Get this from @BotFather on Telegram: /newbot)
# ============================================================

BOT_TOKEN = "8293625592:AAHSXnU-X2HhXhi45yhC9mCZgksVM1Tr5RE"


# ============================================================
# TELEGRAM OWNER ID
# Masukkan Telegram User ID pemilik bot di sini.
# (Get your numeric ID from @userinfobot on Telegram)
# ============================================================

OWNER_ID = 7624612389


# ============================================================
# VERCEL API TOKEN
# Masukkan Vercel API Token di sini.
# (Generate at: https://vercel.com/account/tokens)
# ============================================================

VERCEL_API_KEY = "vcp_2B4lNDwftMUkZUTIUr5aISe2uG699Tk5HKaNfrAC9ywcwnlXRR3iBO0v"


# ============================================================
# OPTIONAL VERCEL TEAM ID
# Only required if your Vercel account/token operates under
# a Team scope. Leave as "" if you deploy under a personal
# account.
# ============================================================

VERCEL_TEAM_ID = "team_rAd4OJTgE2UZA8kcCweGKU0o"


# ============================================================
# OPTIONAL VERCEL PROJECT ID
# Leave as "" to let the bot auto-generate a new project name
# for every deployment. Set this only if you want every
# deployment to attach to one fixed Vercel project.
# ============================================================

VERCEL_PROJECT_ID = "prj_Hv4lCHBJQMTBzmZVEJC28ePfphYv"


# ============================================================
# FILE LIMITS
# ============================================================

MAX_FILE_SIZE = 10 * 1024 * 1024          # Max size for a single HTML file (bytes)
MAX_ZIP_SIZE = 20 * 1024 * 1024           # Max size for an uploaded ZIP archive (bytes)
MAX_EXTRACTED_SIZE = 50 * 1024 * 1024     # Max total size after ZIP extraction (bytes)
MAX_FILES = 500                           # Max number of files allowed inside a ZIP


# ============================================================
# DEPLOYMENT TIMEOUT
# Maximum time (in seconds) the bot will wait for Vercel to
# finish building a deployment before treating it as failed.
# ============================================================

DEPLOYMENT_TIMEOUT = 180


# ============================================================
# HOSTING COOLDOWN
# Minimum time (in seconds) a user must wait between two
# /hosting deployment attempts.
# ============================================================

HOSTING_COOLDOWN = 30


# ============================================================
# DATABASE FILE
# SQLite database used to persist authorized users.
# ============================================================

DATABASE_FILE = "rep76.db"


# ============================================================
# TEMPORARY DIRECTORY
# Base directory used for unique per-deployment scratch space.
# ============================================================

TEMP_DIR = "temporary"


# ============================================================
# LOG FILE
# ============================================================

LOG_FILE = "rep76.log"
