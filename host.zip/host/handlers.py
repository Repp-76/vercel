"""
handlers.py
REP76 WEB HOSTING BOT

All Telegram command and message handlers. Every incoming update is
guaranteed a reply — nothing is left unanswered.
"""

import asyncio
import os

from telegram import Update
from telegram.constants import ParseMode
from telegram.ext import ContextTypes

import config
import database
import hosting
from utils import logger, rate_limiter

DIVIDER = "\u2501" * 30  # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━

FOOTER = "DEVELOPER \u00b7 REP76"


def _wrap(body: str) -> str:
    return f"{DIVIDER}\n\n{body}\n\n{DIVIDER}\n\n{FOOTER}"


# ------------------------------------------------------------------
# /start
# ------------------------------------------------------------------

async def start_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    user_id = update.effective_user.id

    if database.has_access(user_id):
        body = (
            "REP76 WEB HOSTING\n\n"
            "PROFESSIONAL WEB DEPLOYMENT SYSTEM\n\n"
            "STATUS\nSYSTEM ONLINE\n\n"
            "ENGINE\nVERCEL DEPLOYMENT\n\n"
            "ACCESS\nAUTHORIZED\n\n"
            f"{DIVIDER}\n\n"
            "SUPPORTED FILES\n\n.HTML\n.ZIP\n\n"
            "WORKFLOW\n\n"
            "01  Upload your website file\n"
            "02  Reply to the file with /hosting\n"
            "03  Wait for deployment\n"
            "04  Receive your live website URL"
        )
    else:
        body = (
            "REP76 WEB HOSTING\n\n"
            "PROFESSIONAL WEB DEPLOYMENT SYSTEM\n\n"
            "STATUS\nSYSTEM ONLINE\n\n"
            "ENGINE\nVERCEL DEPLOYMENT\n\n"
            "ACCESS\nNOT AUTHORIZED\n\n"
            f"{DIVIDER}\n\n"
            "Please purchase access from @Repp76."
        )

    await update.message.reply_text(_wrap(body))


# ------------------------------------------------------------------
# /help
# ------------------------------------------------------------------

async def help_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    body = (
        "REP76 WEB HOSTING\nHELP CENTER\n\n"
        "SUPPORTED FILES\n\n.HTML\n.ZIP\n\n"
        "DEPLOYMENT\n\n"
        "1. Upload your HTML or ZIP file.\n"
        "2. Reply to the uploaded file.\n"
        "3. Send /hosting.\n"
        "4. Wait for deployment.\n"
        "5. Receive your live website URL.\n\n"
        "ADMIN COMMANDS\n\n"
        "/giveaccess ID\n/removeaccess ID\n/accesslist"
    )
    await update.message.reply_text(_wrap(body))


# ------------------------------------------------------------------
# /giveaccess
# ------------------------------------------------------------------

async def giveaccess_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    requester_id = update.effective_user.id

    if not database.is_owner(requester_id):
        await update.message.reply_text(_wrap(
            "ACCESS DENIED\n\nYou are not authorized to manage user access."
        ))
        return

    if not context.args:
        await update.message.reply_text(_wrap(
            "INVALID COMMAND\n\nUsage: /giveaccess {telegram_id}"
        ))
        return

    try:
        target_id = int(context.args[0])
    except ValueError:
        await update.message.reply_text(_wrap(
            "INVALID COMMAND\n\nUsage: /giveaccess {telegram_id}"
        ))
        return

    if database.is_owner(target_id):
        await update.message.reply_text(_wrap(
            "OPERATION DENIED\n\nThe bot owner already has full access."
        ))
        return

    granted = database.grant_access(target_id, requester_id)

    if granted:
        logger.info("Access granted | target=%s by=%s", target_id, requester_id)
        body = f"ACCESS GRANTED\n\nUSER ID\n{target_id}\n\nSTATUS\nAUTHORIZED"
    else:
        body = f"ALREADY AUTHORIZED\n\nUSER ID\n{target_id}\n\nSTATUS\nAUTHORIZED"

    await update.message.reply_text(_wrap(body))


# ------------------------------------------------------------------
# /removeaccess
# ------------------------------------------------------------------

async def removeaccess_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    requester_id = update.effective_user.id

    if not database.is_owner(requester_id):
        await update.message.reply_text(_wrap(
            "ACCESS DENIED\n\nYou are not authorized to manage user access."
        ))
        return

    if not context.args:
        await update.message.reply_text(_wrap(
            "INVALID COMMAND\n\nUsage: /removeaccess {telegram_id}"
        ))
        return

    try:
        target_id = int(context.args[0])
    except ValueError:
        await update.message.reply_text(_wrap(
            "INVALID COMMAND\n\nUsage: /removeaccess {telegram_id}"
        ))
        return

    if database.is_owner(target_id):
        await update.message.reply_text(_wrap(
            "OPERATION DENIED\n\nThe bot owner cannot be removed."
        ))
        return

    revoked = database.revoke_access(target_id)

    if revoked:
        logger.info("Access revoked | target=%s by=%s", target_id, requester_id)
        body = f"ACCESS REVOKED\n\nUSER ID\n{target_id}\n\nSTATUS\nREMOVED"
    else:
        body = "ACCESS NOT FOUND\n\nThe specified Telegram ID does not have access."

    await update.message.reply_text(_wrap(body))


# ------------------------------------------------------------------
# /accesslist
# ------------------------------------------------------------------

async def accesslist_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    requester_id = update.effective_user.id

    if not database.is_owner(requester_id):
        await update.message.reply_text(_wrap(
            "ACCESS DENIED\n\nYou are not authorized to manage user access."
        ))
        return

    users = database.list_authorized()

    if users:
        lines = "\n".join(f"{i + 1:02d}  {uid}" for i, uid in enumerate(users))
    else:
        lines = "No authorized users yet."

    body = (
        f"AUTHORIZED USERS\n\n{lines}\n\n"
        f"TOTAL\n{len(users)} USERS\n\n"
        f"OWNER\n{config.OWNER_ID}"
    )
    await update.message.reply_text(_wrap(body))


# ------------------------------------------------------------------
# Document upload (HTML / ZIP / unsupported)
# ------------------------------------------------------------------

_SUPPORTED_EXTENSIONS = (".html", ".htm", ".zip")


async def document_received(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    document = update.message.document
    filename = document.file_name or "file"
    lower_name = filename.lower()

    if lower_name.endswith((".html", ".htm")):
        body = (
            f"FILE RECEIVED\n\nFILE\n{filename}\n\n"
            f"TYPE\nHTML WEBSITE\n\nSTATUS\nREADY FOR DEPLOYMENT\n\n"
            f"{DIVIDER}\n\nReply to this file with:\n\n/hosting"
        )
        await update.message.reply_text(_wrap(body))
        return

    if lower_name.endswith(".zip"):
        body = (
            f"FILE RECEIVED\n\nFILE\n{filename}\n\n"
            f"TYPE\nWEBSITE PACKAGE\n\nSTATUS\nREADY FOR DEPLOYMENT\n\n"
            f"{DIVIDER}\n\nReply to this file with:\n\n/hosting"
        )
        await update.message.reply_text(_wrap(body))
        return

    body = (
        "UNSUPPORTED FILE\n\nThis file type is not supported.\n\n"
        "Supported formats:\n\n.HTML\n.ZIP"
    )
    await update.message.reply_text(_wrap(body))


# ------------------------------------------------------------------
# /hosting  (main deployment workflow)
# ------------------------------------------------------------------

async def hosting_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    user_id = update.effective_user.id
    reply_target = update.message.reply_to_message

    if reply_target is None or reply_target.document is None:
        await update.message.reply_text(_wrap(
            "INVALID REQUEST\n\nReply to an HTML or ZIP file with /hosting."
        ))
        return

    document = reply_target.document
    filename = document.file_name or "file"
    lower_name = filename.lower()

    if not lower_name.endswith(_SUPPORTED_EXTENSIONS):
        await update.message.reply_text(_wrap(
            "INVALID REQUEST\n\nReply to an HTML or ZIP file with /hosting."
        ))
        return

    if not database.has_access(user_id):
        await update.message.reply_text(_wrap(
            "ACCESS REQUIRED\n\nYou do not have access to this hosting system.\n\n"
            "Please purchase access from @Repp76."
        ))
        return

    if rate_limiter.is_limited(user_id):
        remaining = rate_limiter.remaining_seconds(user_id)
        await update.message.reply_text(_wrap(
            f"RATE LIMIT\n\nPlease wait {remaining}s before starting another deployment."
        ))
        return

    if document.file_size and document.file_size > config.MAX_ZIP_SIZE:
        await update.message.reply_text(_wrap(
            "FILE REJECTED\n\nThe uploaded file exceeds the allowed size limit."
        ))
        return

    rate_limiter.record_attempt(user_id)

    chat_id = update.effective_chat.id
    processing_msg = await update.message.reply_text(_wrap(
        f"REP76 DEPLOYMENT SYSTEM\n\nSTATUS\nPROCESSING\n\n"
        f"FILE\n{filename}\n\nENGINE\nVERCEL\n\n"
        f"{DIVIDER}\n\nPreparing website deployment...\n\nPlease wait."
    ))

    temp_dir = hosting.make_temp_dir()

    try:
        await _set_status(context, chat_id, processing_msg.message_id, "VALIDATING FILE")

        tg_file = await context.bot.get_file(document.file_id)
        local_path = os.path.join(temp_dir, filename)
        await tg_file.download_to_drive(local_path)

        await _set_status(context, chat_id, processing_msg.message_id, "PREPARING WEBSITE")

        if lower_name.endswith(".zip"):
            files = await asyncio.to_thread(hosting.build_files_from_zip, local_path, temp_dir)
        else:
            with open(local_path, "rb") as f:
                html_bytes = f.read()
            files = hosting.build_files_from_html(html_bytes, filename)

        await _set_status(context, chat_id, processing_msg.message_id, "UPLOADING TO VERCEL")
        await _set_status(context, chat_id, processing_msg.message_id, "BUILDING DEPLOYMENT")

        url = await asyncio.to_thread(hosting.deploy, files, filename)

        await _set_status(context, chat_id, processing_msg.message_id, "VERIFYING WEBSITE")

        await context.bot.delete_message(chat_id, processing_msg.message_id)
        await update.message.reply_text(_wrap(
            f"WEBSITE IS NOW LIVE\n\nYour website has been successfully deployed.\n\n"
            f"{DIVIDER}\n\nLIVE WEBSITE\n\n{url}\n\n"
            f"{DIVIDER}\n\nDEPLOYMENT\nREADY\n\nFILE\n{filename}"
        ))

    except hosting.HostingError as exc:
        logger.info("Deployment rejected | user=%s reason=%s", user_id, exc)
        await _safe_delete(context, chat_id, processing_msg.message_id)
        await update.message.reply_text(_wrap(
            f"DEPLOYMENT FAILED\n\n{exc}\n\nSTATUS\nFAILED\n\n"
            f"Please check your website files and try again.\n\n"
            f"REFERENCE\nREP76-DEPLOYMENT"
        ))

    except Exception:
        logger.exception("Unexpected deployment error | user=%s", user_id)
        await _safe_delete(context, chat_id, processing_msg.message_id)
        await update.message.reply_text(_wrap(
            "DEPLOYMENT FAILED\n\nThe website could not be deployed.\n\n"
            "STATUS\nFAILED\n\nPlease check your website files and try again.\n\n"
            "REFERENCE\nREP76-DEPLOYMENT"
        ))

    finally:
        hosting.cleanup_temp_dir(temp_dir)


async def _set_status(context: ContextTypes.DEFAULT_TYPE, chat_id: int,
                       message_id: int, status: str) -> None:
    try:
        await context.bot.edit_message_text(
            chat_id=chat_id,
            message_id=message_id,
            text=_wrap(f"REP76 DEPLOYMENT SYSTEM\n\nSTATUS\n{status}"),
        )
    except Exception:
        # Editing failures (e.g. identical content, rate limit) are
        # non-fatal — the deployment keeps proceeding regardless.
        pass


async def _safe_delete(context: ContextTypes.DEFAULT_TYPE, chat_id: int, message_id: int) -> None:
    try:
        await context.bot.delete_message(chat_id, message_id)
    except Exception:
        pass


# ------------------------------------------------------------------
# Fallbacks: unknown command / unknown text
# ------------------------------------------------------------------

async def unknown_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    await update.message.reply_text(_wrap(
        "UNKNOWN COMMAND\n\nI don't recognize that command.\n\n"
        "Use /help to view available commands."
    ))


async def unknown_text(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    await update.message.reply_text(_wrap(
        "REP76 WEB HOSTING\n\nI don't recognize that request.\n\n"
        "Use /help to view the available commands."
    ))
