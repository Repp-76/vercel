"""
database.py
REP76 WEB HOSTING BOT

Persistent SQLite storage for authorized users. The owner defined in
config.py always has access implicitly and is never stored as a row
(so ownership cannot accidentally be revoked from the database).
"""

import sqlite3
import threading
import time

import config

_lock = threading.Lock()


def _connect() -> sqlite3.Connection:
    conn = sqlite3.connect(config.DATABASE_FILE)
    conn.row_factory = sqlite3.Row
    return conn


def init_db() -> None:
    """Creates the database and required tables if they do not exist."""
    with _lock, _connect() as conn:
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS authorized_users (
                telegram_id INTEGER PRIMARY KEY,
                granted_at  TEXT NOT NULL,
                granted_by  INTEGER NOT NULL,
                status      TEXT NOT NULL DEFAULT 'active'
            )
            """
        )
        conn.commit()


def is_owner(telegram_id: int) -> bool:
    return telegram_id == config.OWNER_ID


def has_access(telegram_id: int) -> bool:
    if is_owner(telegram_id):
        return True
    with _lock, _connect() as conn:
        row = conn.execute(
            "SELECT status FROM authorized_users WHERE telegram_id = ?",
            (telegram_id,),
        ).fetchone()
        return row is not None and row["status"] == "active"


def grant_access(telegram_id: int, granted_by: int) -> bool:
    """
    Returns True if access was newly granted, False if the user
    already had active access.
    """
    if is_owner(telegram_id):
        return False

    with _lock, _connect() as conn:
        existing = conn.execute(
            "SELECT status FROM authorized_users WHERE telegram_id = ?",
            (telegram_id,),
        ).fetchone()

        if existing is not None and existing["status"] == "active":
            return False

        if existing is not None:
            conn.execute(
                "UPDATE authorized_users SET status = 'active', "
                "granted_at = ?, granted_by = ? WHERE telegram_id = ?",
                (str(int(time.time())), granted_by, telegram_id),
            )
        else:
            conn.execute(
                "INSERT INTO authorized_users (telegram_id, granted_at, "
                "granted_by, status) VALUES (?, ?, ?, 'active')",
                (telegram_id, str(int(time.time())), granted_by),
            )
        conn.commit()
        return True


def revoke_access(telegram_id: int) -> bool:
    """
    Returns True if a currently-active user was revoked, False if
    the id had no active access to begin with.
    """
    if is_owner(telegram_id):
        return False

    with _lock, _connect() as conn:
        existing = conn.execute(
            "SELECT status FROM authorized_users WHERE telegram_id = ?",
            (telegram_id,),
        ).fetchone()

        if existing is None or existing["status"] != "active":
            return False

        conn.execute(
            "UPDATE authorized_users SET status = 'removed' "
            "WHERE telegram_id = ?",
            (telegram_id,),
        )
        conn.commit()
        return True


def list_authorized() -> list:
    """Returns a list of telegram_id ints with active access (owner excluded)."""
    with _lock, _connect() as conn:
        rows = conn.execute(
            "SELECT telegram_id FROM authorized_users WHERE status = 'active' "
            "ORDER BY granted_at ASC"
        ).fetchall()
        return [row["telegram_id"] for row in rows]
