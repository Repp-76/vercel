"""
security.py
REP76 WEB HOSTING BOT

Safe ZIP extraction and validation. Protects the host system from:
  - path traversal (../, ../../, absolute paths)
  - symlink attacks
  - zip bombs / excessive extraction size
  - excessive file counts
  - malicious / unsafe filenames
"""

import os
import zipfile

import config


class SecurityError(Exception):
    """Raised when an uploaded archive fails a safety check."""


def _is_safe_member_path(member_name: str) -> bool:
    if member_name.startswith("/") or member_name.startswith("\\"):
        return False
    if ":" in member_name:  # Windows drive letters, e.g. C:\
        return False

    normalized = os.path.normpath(member_name)
    if normalized.startswith("..") or normalized.startswith(os.sep):
        return False
    if normalized == ".":
        return False

    return True


def validate_zip(zip_path: str) -> zipfile.ZipFile:
    """
    Opens and validates a ZIP archive without extracting it.
    Raises SecurityError on any violation. Returns the open ZipFile
    handle for the caller to proceed with extraction.
    """
    try:
        zf = zipfile.ZipFile(zip_path, "r")
    except zipfile.BadZipFile:
        raise SecurityError("The uploaded file is not a valid ZIP archive.")

    infolist = zf.infolist()

    if len(infolist) == 0:
        zf.close()
        raise SecurityError("The ZIP archive is empty.")

    if len(infolist) > config.MAX_FILES:
        zf.close()
        raise SecurityError("The ZIP archive contains too many files.")

    total_uncompressed = 0
    has_index = False

    for info in infolist:
        name = info.filename

        # Reject symlinks: unix mode bits stored in high 16 bits of
        # external_attr; 0xA000 == S_IFLNK.
        unix_mode = (info.external_attr >> 16) & 0xFFFF
        if unix_mode and (unix_mode & 0xF000) == 0xA000:
            zf.close()
            raise SecurityError("The ZIP archive contains a symbolic link.")

        if not _is_safe_member_path(name):
            zf.close()
            raise SecurityError("The ZIP archive contains an unsafe file path.")

        total_uncompressed += info.file_size
        if total_uncompressed > config.MAX_EXTRACTED_SIZE:
            zf.close()
            raise SecurityError("The extracted contents exceed the allowed size limit.")

        if not name.endswith("/") and os.path.basename(name).lower() == "index.html":
            has_index = True

    if not has_index:
        zf.close()
        raise SecurityError("The ZIP archive must contain an index.html file.")

    return zf


def safe_extract(zf: zipfile.ZipFile, destination_dir: str) -> None:
    """
    Extracts a pre-validated ZipFile into destination_dir, re-checking
    every member path resolves inside destination_dir before writing.
    """
    destination_dir = os.path.realpath(destination_dir)
    os.makedirs(destination_dir, exist_ok=True)

    for info in zf.infolist():
        target_path = os.path.realpath(os.path.join(destination_dir, info.filename))

        if not (target_path == destination_dir or
                target_path.startswith(destination_dir + os.sep)):
            raise SecurityError("Blocked a path traversal attempt during extraction.")

        if info.filename.endswith("/"):
            os.makedirs(target_path, exist_ok=True)
            continue

        os.makedirs(os.path.dirname(target_path), exist_ok=True)
        with zf.open(info, "r") as source, open(target_path, "wb") as target:
            target.write(source.read())

    zf.close()
