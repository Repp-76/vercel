"""
bot.py
REP76 WEB HOSTING BOT

Main entry point. Builds the Telegram application, registers every
handler, ensures the database and temp directories exist, and starts
polling.

Run with:
    python bot.py
"""

import os

from telegram.ext import (
    Application,
    CommandHandler,
    MessageHandler,
    filters,
)

import config
import database
import handlers
from utils import logger


def main() -> None:
    if config.BOT_TOKEN == "8293625592:AAHSXnU-X2HhXhi45yhC9mCZgksVM1Tr5RE":
        raise SystemExit(
            "BOT_TOKEN is not configured. Open config.py and paste your "
            "Telegram bot token before running the bot."
        )

    if config.VERCEL_API_KEY == "vcp_2B4lNDwftMUkZUTIUr5aISe2uG699Tk5HKaNfrAC9ywcwnlXRR3iBO0v":
        raise SystemExit(
            "VERCEL_API_KEY is not configured. Open config.py and paste "
            "your Vercel API token before running the bot."
        )

    os.makedirs(config.TEMP_DIR, exist_ok=True)
    database.init_db()

    application = Application.builder().token(config.BOT_TOKEN).build()

    # Core commands
    application.add_handler(CommandHandler("start", handlers.start_command))
    application.add_handler(CommandHandler("help", handlers.help_command))
    application.add_handler(CommandHandler("hosting", handlers.hosting_command))

    # Admin commands
    application.add_handler(CommandHandler("giveaccess", handlers.giveaccess_command))
    application.add_handler(CommandHandler("removeaccess", handlers.removeaccess_command))
    application.add_handler(CommandHandler("accesslist", handlers.accesslist_command))

    # File uploads
    application.add_handler(MessageHandler(filters.Document.ALL, handlers.document_received))

    # Fallbacks — must be registered last.
    application.add_handler(MessageHandler(filters.COMMAND, handlers.unknown_command))
    application.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handlers.unknown_text))

    logger.info("REP76 Web Hosting Bot starting")
    application.run_polling(allowed_updates=["message"])


if __name__ == "__main__":
    main()
