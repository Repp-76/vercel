# REP76 WEB HOSTING BOT

A Telegram bot that lets authorized users upload an HTML file or a ZIP
website package and deploys it live to Vercel automatically, using the
real Vercel REST API.

Developer: **REP76**

---

## 1. What this is

REP76 Web Hosting is a self-hosted Telegram bot. Authorized users reply
to an uploaded `.html` or `.zip` file with `/hosting`, and the bot
uploads and deploys that site to Vercel, returning the live URL once
the deployment is confirmed `READY`.

Access is controlled by the bot owner through `/giveaccess`,
`/removeaccess`, and `/accesslist`. Authorization is stored in a local
SQLite database (`rep76.db`) and survives bot restarts.

---

## 2. Python version

Python 3.10 or newer is required (3.11+ recommended).

---

## 3. Installing Python

- **Windows / macOS:** download from https://www.python.org/downloads/
  and make sure "Add Python to PATH" is checked during install.
- **Linux (Debian/Ubuntu):** `sudo apt install python3 python3-pip`
- **Termux (Android):** `pkg install python`

Verify with:

```
python --version
```

---

## 4. Installing requirements

From inside the project folder:

```
pip install -r requirements.txt
```

---

## 5. Creating a Telegram bot via BotFather

1. Open Telegram and search for **@BotFather**.
2. Send `/newbot`.
3. Choose a display name, then a unique username ending in `bot`.
4. BotFather will reply with your bot token.

---

## 6. Getting your Bot Token

The token is shown by BotFather immediately after `/newbot`. It looks
like:

```
123456789:AAExampleTokenStringHere
```

You can retrieve it again anytime via BotFather's `/mybots` menu.

---

## 7. Getting your Telegram User ID

1. Open Telegram and search for **@userinfobot**.
2. Send any message.
3. It replies with your numeric Telegram ID — this is your `OWNER_ID`.

---

## 8. Getting a Vercel API Token

1. Log in to https://vercel.com
2. Go to **Account Settings → Tokens**
   (direct link: https://vercel.com/account/tokens)
3. Click **Create Token**, name it, and copy the generated value
   immediately — Vercel only shows it once.

---

## 9. Where to place your credentials

Open `config.py` and fill in the three placeholder values:

```python
BOT_TOKEN = "PASTE_YOUR_TELEGRAM_BOT_TOKEN_HERE"
OWNER_ID = 123456789
VERCEL_API_KEY = "PASTE_YOUR_VERCEL_API_KEY_HERE"
```

If your Vercel token belongs to a Team account, also fill in
`VERCEL_TEAM_ID`.

**`config.py` contains private credentials and must never be publicly
shared or uploaded to a public repository.** It is already listed in
`.gitignore` for this reason.

---

## 10. Running the bot

```
python bot.py
```

The bot will create `rep76.db` and the `temporary/` scratch directory
automatically on first run, then start polling for Telegram updates.

---

## 11. Using /start

Send `/start` at any time. If you have access, the bot shows the
system status and the deployment workflow. If you don't, it directs
you to purchase access from @Repp76.

---

## 12. Using /help

Send `/help` to see the supported file types, the deployment steps,
and (for the owner) the admin command list.

---

## 13. Giving access

Only the owner can run this:

```
/giveaccess 123456789
```

Replace `123456789` with the target user's Telegram ID.

---

## 14. Removing access

Only the owner can run this:

```
/removeaccess 123456789
```

The owner account itself can never be removed.

---

## 15. Viewing the access list

Only the owner can run this:

```
/accesslist
```

Shows every currently authorized user ID and the total count.

---

## 16. Uploading an HTML file

Send a single `.html` file directly to the bot as a Telegram document
(not as a text message). The bot confirms receipt and tells you to
reply to it with `/hosting`.

---

## 17. Uploading a ZIP package

Send a `.zip` file containing your website. It **must** contain an
`index.html` at its root (or inside a single top-level folder). It may
also include `style.css`, `script.js`, images, fonts, and other static
assets. The bot confirms receipt the same way as an HTML upload.

---

## 18. Using /hosting

1. Upload your `.html` or `.zip` file.
2. **Reply directly to that file's message** with `/hosting`.
3. The bot validates the file, uploads it to Vercel, and waits for the
   build to finish.
4. On success you receive the live URL. On failure you receive a
   clear failure message.

`/hosting` only works as a reply to a file message — sending it on its
own returns an "INVALID REQUEST" notice.

---

## 19. How Vercel deployment works internally

1. Each file's bytes are uploaded to Vercel's content-addressable file
   store (`/v2/files`), keyed by its SHA-1 digest.
2. A deployment is created (`/v13/deployments`) referencing those
   files.
3. The bot polls the deployment status until Vercel reports `READY`,
   `ERROR`, or `CANCELED`, or until `DEPLOYMENT_TIMEOUT` (in
   `config.py`) is reached.
4. The live URL returned to you always comes directly from Vercel's
   API response — nothing is hardcoded or guessed.

---

## 20. Security notes

- `config.py` and `rep76.db` are excluded from git via `.gitignore` —
  never remove them from that file.
- ZIP uploads are protected against path traversal, symlinks, zip
  bombs, and excessive file counts before a single byte is extracted.
- Every extraction happens inside a unique temporary directory that is
  deleted after each deployment attempt, success or failure.
- The bot never logs your `BOT_TOKEN`, `VERCEL_API_KEY`, or uploaded
  file contents.
- Only the owner ID configured in `config.py` can manage access;
  everyone else is rejected on admin commands.

---

## 21. Troubleshooting

**Bot doesn't respond at all**
Check that `python bot.py` is still running and that `BOT_TOKEN` in
`config.py` is correct and unmodified from BotFather.

**"BOT_TOKEN is not configured" on startup**
You haven't replaced the placeholder value in `config.py` yet.

**"ACCESS REQUIRED" when trying to use /hosting**
Ask the owner to run `/giveaccess <your_telegram_id>`.

**"INVALID REQUEST" when using /hosting**
`/hosting` must be sent as a **reply** to the message containing your
`.html` or `.zip` file, not as a standalone message.

**"INVALID WEBSITE PACKAGE"**
Your ZIP does not contain an `index.html` file at a valid location.

**"DEPLOYMENT FAILED"**
Check the bot's console/log output (`rep76.log`) for the underlying
Vercel error, and confirm `VERCEL_API_KEY` (and `VERCEL_TEAM_ID` if
applicable) in `config.py` are correct and active.

**Deployment times out**
Increase `DEPLOYMENT_TIMEOUT` in `config.py` if your site is large or
your network is slow.

---

DEVELOPER · REP76
